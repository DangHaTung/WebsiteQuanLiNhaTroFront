import React, { useEffect, useState } from "react";
import { Card, Table, Tag, Space, Select, Popconfirm, Button, message } from "antd";
import type { ColumnsType } from "antd/es/table";
import { DeleteOutlined, ReloadOutlined } from "@ant-design/icons";
import { adminComplaintService, type Complaint } from "../services/complaint";

const statusOptions = [
  { label: "Pending", value: "pending" },
  { label: "Processing", value: "processing" },
  { label: "Resolved", value: "resolved" },
  { label: "Rejected", value: "rejected" },
];

const statusColor = (status?: string) => {
  switch ((status || "").toLowerCase()) {
    case "pending":
      return "gold";
    case "processing":
      return "blue";
    case "resolved":
      return "green";
    case "rejected":
      return "red";
    default:
      return "default";
  }
};

const Complaints: React.FC = () => {
  const [data, setData] = useState<Complaint[]>([]);
  const [loading, setLoading] = useState(false);
  const [page, setPage] = useState(1);
  const [limit, setLimit] = useState(10);
  const [total, setTotal] = useState(0);

  const fetchData = async (p = page, l = limit) => {
    setLoading(true);
    try {
      const res = await adminComplaintService.list(p, l);
      setData(res.data || []);
      setTotal(res.pagination?.totalRecords || 0);
    } catch (err: any) {
      message.error(err?.response?.data?.message || "Lỗi khi tải complaints");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData(1, limit);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleStatusChange = async (id: string, status: string) => {
    try {
      await adminComplaintService.updateStatus(id, status);
      message.success("Cập nhật trạng thái thành công");
      fetchData(page, limit);
    } catch (err: any) {
      message.error(err?.response?.data?.message || "Cập nhật trạng thái thất bại");
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await adminComplaintService.remove(id);
      message.success("Đã xóa complaint");
      const remaining = total - 1;
      const maxPage = Math.max(1, Math.ceil(remaining / limit));
      const nextPage = Math.min(page, maxPage);
      setPage(nextPage);
      fetchData(nextPage, limit);
    } catch (err: any) {
      message.error(err?.response?.data?.message || "Xóa complaint thất bại");
    }
  };

  const columns: ColumnsType<Complaint> = [
    {
      title: "Tiêu đề",
      dataIndex: "title",
      key: "title",
      render: (text) => (
        <span style={{ fontWeight: 600 }}>{(text || "").trim() || "(Không có tiêu đề)"}</span>
      ),
    },
    {
      title: "Mô tả",
      dataIndex: "description",
      key: "description",
      ellipsis: true,
    },
    {
      title: "Tenant",
      dataIndex: "tenantId",
      key: "tenantId",
      width: 180,
      render: (v) => <code>{v}</code>,
    },
    {
      title: "Trạng thái",
      dataIndex: "status",
      key: "status",
      width: 180,
      render: (value: string, record) => (
        <Space>
          <Tag color={statusColor(value)}>{value || "pending"}</Tag>
          <Select
            size="small"
            style={{ width: 130 }}
            value={(value || "").toLowerCase() || "pending"}
            onChange={(val) => handleStatusChange(record._id, val)}
            options={statusOptions}
          />
        </Space>
      ),
    },
    {
      title: "Tạo lúc",
      dataIndex: "createdAt",
      key: "createdAt",
      width: 180,
      render: (v?: string) => (v ? new Date(v).toLocaleString("vi-VN") : ""),
    },
    {
      title: "Thao tác",
      key: "actions",
      width: 120,
      render: (_, record) => (
        <Space>
          <Popconfirm
            title="Xóa complaint này?"
            okText="Xóa"
            cancelText="Hủy"
            onConfirm={() => handleDelete(record._id)}
          >
            <Button danger size="small" icon={<DeleteOutlined />}>Xóa</Button>
          </Popconfirm>
        </Space>
      ),
    },
  ];

  return (
    <div style={{ maxWidth: 1200, margin: "24px auto", padding: "0 16px" }}>
      <Card
        title="Quản lý Complaints"
        extra={
          <Space>
            <Button icon={<ReloadOutlined />} onClick={() => fetchData(page, limit)}>
              Tải lại
            </Button>
          </Space>
        }
      >
        <Table
          rowKey="_id"
          loading={loading}
          columns={columns}
          dataSource={data}
          pagination={{
            current: page,
            pageSize: limit,
            total,
            showSizeChanger: true,
            pageSizeOptions: [5, 10, 20, 50],
            onChange: (p, l) => {
              setPage(p);
              setLimit(l);
              fetchData(p, l);
            },
            showTotal: (t) => `${t} complaints`,
          }}
        />
      </Card>
    </div>
  );
};

export default Complaints;
