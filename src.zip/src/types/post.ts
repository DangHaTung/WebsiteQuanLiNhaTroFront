export interface Post {
  id: number;
  title: string;
  excerpt: string;
  image: string;
  createdAt: string;
}
